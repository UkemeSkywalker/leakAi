# LeakAI Chrome Extension - Installation Guide

## Production Build v1.0.0
Built on: 8/24/2025

## Installation Instructions

### Method 1: Load Unpacked Extension (Recommended for Testing)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right corner)
3. Click "Load unpacked"
4. Select the `dist/` folder from this package
5. The extension should now appear in your extensions list

### Method 2: Install from CRX File (If Available)

1. Download the `.crx` file
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode"
4. Drag and drop the `.crx` file onto the extensions page
5. Click "Add extension" when prompted

## Verification

After installation, verify the extension is working:

1. Click the LeakAI icon in the Chrome toolbar
2. Ensure the popup opens and shows "Active" status
3. Navigate to any website with text inputs
4. Type sensitive data (like an email address)
5. Verify colored underlines appear under sensitive data

## Features

- Real-time detection of sensitive data as you type
- Visual indicators with colored underlines
- Tooltips with explanations and remediation actions
- Form submission warnings for high-risk data
- Configurable detection categories
- Cross-tab settings synchronization

## Support

For issues or questions:
- Check the browser console for error messages
- Verify all detection categories are enabled in settings
- Try refreshing the page if detection isn't working
- Restart Chrome if settings aren't syncing

## File Structure

```
dist/
├── manifest.json          # Extension manifest
├── background/            # Background service worker
├── content/              # Content scripts and styles
├── popup/                # Extension popup interface
├── patterns/             # Detection engine and patterns
├── icons/                # Extension icons
└── package-info.json     # Build information
```

## Security

This extension:
- Processes all data locally in your browser
- Never sends data to external servers
- Uses Chrome's secure storage APIs
- Follows Chrome extension security best practices

Built with ❤️ for data privacy and security.
